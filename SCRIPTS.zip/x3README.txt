It is important to be able to run the TPC and TPG macros from the command line, specifying an argument, e.g.

x3TPC,10 means: show temperatures in layer 10, in subsequent seconds.

Similarly

x3TPG,5 means: show temperatures in the 5th second, in subsequent layers.

For this to work, the scripts must be in the working directory and have the .mac extension